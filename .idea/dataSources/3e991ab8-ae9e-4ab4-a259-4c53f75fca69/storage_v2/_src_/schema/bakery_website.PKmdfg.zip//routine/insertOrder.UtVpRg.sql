create
    definer = root@localhost procedure insertOrder(IN order_date date, IN name varchar(100), IN email varchar(100),
                                                   IN phone varchar(11), IN address varchar(200))
begin
	insert into orders (order_date, customer_name, customer_email, customer_phone, customer_address)
    values(order_date, name, email, phone, address);
end;

